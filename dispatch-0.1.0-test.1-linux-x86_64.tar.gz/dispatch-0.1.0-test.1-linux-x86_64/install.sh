#!/bin/sh
# Install Dispatch for this user: programs in ~/.local/bin, a menu entry, and (with sudo) the
# Digirig Lite permission rule. Run from the unpacked folder:  ./install.sh
set -e
cd "$(dirname "$0")"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
cp bin/dispatch-gui bin/dispatch-tui bin/dispatch-station "$HOME/.local/bin/"
cp dispatch.desktop "$HOME/.local/share/applications/"
echo "Installed dispatch-gui, dispatch-tui and dispatch-station in ~/.local/bin"
case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) echo "Add ~/.local/bin to your PATH";; esac
if ! id -nG | grep -qw dialout; then
    echo "For CAT and Digirig Mobile PTT: sudo usermod -aG dialout $USER  (then log out and in)"
fi
if [ ! -f /etc/udev/rules.d/99-dispatch-digirig.rules ]; then
    echo "For Digirig Lite PTT: sudo cp 99-dispatch-digirig.rules /etc/udev/rules.d/ && sudo udevadm control --reload"
fi
